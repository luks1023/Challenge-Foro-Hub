package com.challengefinal.forohub.domain.respuesta;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Fetch;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "respuestas")
@Entity(name = "Respuesta")
@EqualsAndHashCode(of = "id")



public class Respuesta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String mensaje;

    @Column(name = "fecha_creacion")
    private LocalDateTime ultimaActualizacion;
    private Boolean solucion;
    private Boolean borrado;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "topico_id")
    private Topico topico;


//    public Respuesta(CrearRespuestaDTO crearRespuestaDTO, Usuario){
//        this.mensaje =crearRespuestaDTO.mensaje();
//        this.fechaCreacion =LocalDateTime.now();
//        this.ultimaActualizacion =LocalDateTime.now();
//        this.solucion =false;
//        this.borrado =false;
//        this.usuario = usuario;
//        this.topico = topico;
}




}
