package com.challengefinal.forohub.domain.curso.dto;

import com.challengefinal.forohub.domain.curso.Categoria;

public record ActualizarCursoDTO(
        String name,
        Categoria categoria,
        Boolean activo
) {
}
