package com.challengefinal.forohub.domain.curso;

public enum Categoria {

    FRONTEND,
    BACKEND,
    DEVOPS,
    ROBOTICS,
    IA

}
