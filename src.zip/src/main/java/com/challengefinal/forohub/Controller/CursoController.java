package com.challengefinal.forohub.Controller;


import com.challengefinal.forohub.domain.curso.Curso;

import com.challengefinal.forohub.domain.curso.dto.ActualizarCursoDTO;
import com.challengefinal.forohub.domain.curso.dto.CrearCursoDTO;
import com.challengefinal.forohub.domain.curso.dto.DetalleCursoDTO;

import com.challengefinal.forohub.domain.curso.repository.CursoRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;
import tools.jackson.core.PrettyPrinter;


@RestController
@RequestMapping("/cursos")
@SecurityRequirement(name = "bearer-key")
@Tag(name = "Curso", description = "Puede pertenecer a una de las muchas categorias definidas")



public class CursoController {

    @Autowired
    private CursoRepository repository;

    @PostMapping
    @Transactional
    @Operation(summary = "Registrar el curso nuevo en la BD.")

    public ResponseEntity<DetalleCursoDTO> crearTopico(@RequestBody @Valid CrearCursoDTO crearCursoDTO,
                                                       UriComponentsBuilder uriBuilder) {

        Curso curso = new Curso(crearCursoDTO);
        repository.save(curso);
        var uri = uriBuilder.path("/cursos/{i}").buildAndExpand(curso.getId()).toUri();

        return ResponseEntity.created(uri).body(new DetalleCursoDTO(curso));

    }


    @GetMapping("/all")
    @Operation(summary = "Lee todos los cursos")
    public ResponseEntity<Page<DetalleCursoDTO>> listarCursos(Pageable pageable) {

        Page<DetalleCursoDTO> pagina = repository
                .findAll(pageable)
                .map(DetalleCursoDTO::new);

        return ResponseEntity.ok(pagina);
    }

    @GetMapping
    @Operation(summary = "Lista de todos los cursos activos")
    public ResponseEntity<Page<DetalleCursoDTO>> listarCurso(Pageable pageable) {

        Page<DetalleCursoDTO> pagina = repository
                .findAllByActivoTrue(pageable)
                .map(DetalleCursoDTO::new);

        return ResponseEntity.ok(pagina);
    }


    @GetMapping("/{id}")
    @Operation(summary = "Lee un solo curso por su ID")
    public ResponseEntity<DetalleCursoDTO> listarUnCurso(@PathVariable Long id) {

        Curso curso = repository.getReferenceById(id);

        DetalleCursoDTO datosDelCurso = new DetalleCursoDTO(
                curso.getId(),
                curso.getName(),
                curso.getCategoria(),
                curso.getActivo()
        );

        return ResponseEntity.ok(datosDelCurso);
    }


    @PutMapping("/{id}")
    @Transactional
    @Operation(summary = "Actualiza el nombre, la categoria")

    public ResponseEntity<DetalleCursoDTO> actualizarCurso(@RequestBody @Valid ActualizarCursoDTO actualizarCursoDTO, @PathVariable Long id) {
        Curso curso = repository.getReferenceById(id);
        curso.actualizarCurso(actualizarCursoDTO);
        var datosDelCurso = new DetalleCursoDTO(
                curso.getId(),
                curso.getName(),
                curso.getCategoria(),
                curso.getActivo()
        );
        return ResponseEntity.ok(datosDelCurso);

    }


    @PutMapping("/{id}")
    @Transactional
    @Operation(summary = "Elimina el curso")
    public ResponseEntity<?>eliminarCurso(@PathVariable Long id) {
        Curso curso = repository.getReferenceById(id);
        curso.eliminarCurso();
        return ResponseEntity.noContent().build();
    }


}
